use search_engine::api::search_engine::SearchEngine;

#[test]
fn layout_metadata() {
    println!(
        "OTZARIA_LAYOUT {{\"size_bytes\":{},\"alignment_bytes\":{}}}",
        std::mem::size_of::<SearchEngine>(),
        std::mem::align_of::<SearchEngine>()
    );
}

fn main() {}
